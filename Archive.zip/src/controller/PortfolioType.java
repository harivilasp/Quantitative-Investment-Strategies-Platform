package controller;

/**
 * This is enum of different type of portfolios.
 */
public enum PortfolioType {
  INFLEXIBLE, FLEXIBLE
}
