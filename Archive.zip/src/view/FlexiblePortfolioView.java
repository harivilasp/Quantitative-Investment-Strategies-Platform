package view;

public class FlexiblePortfolioView {
}
